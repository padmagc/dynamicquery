﻿var pageName = "FieldType.aspx";
var typeid = -1;
var subtypeid = -1;
var types = '';
var subtypes = '';
function InitFormSpec() {
    $("#dialogType").hide();
    $("#dialogSubType").hide();
    GetTypes();
    $("#newType").click(function () {
        typeid = -1;
        ShowTypeDialog();
    });
    $("#newSubType").click(function () {
        subtypeid = -1;
        ShowSubTypeDialog();
    });
}

function GetTypes() {
    $.ajax({
        type: "POST",
        url: pageName + "/GetTypes",
        data: null,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            typeid = -1;
            types = data.d;
            $("#placeholderType").setTemplateURL('Templates/Type3.htm', null, { filter_data: false });
            $("#placeholderType").processTemplate(data.d);

            $('.selecttpye').click(function (e) {
                typeid = this.id.substr(6);
                $.each(types, function(i, v) {
                    if (v.Id == typeid) {
                        subtypes = v.SubType;
                        ShowSubTypes();
                        return ;
                    }
                });
            });
            $('.deletetpye').click(function (e) {
                DeleteType(this.id.substr(6));
            });
            $('.activatetpye').click(function (e) {
                ActivateType(this.id.substr(8));
            });
            $('.updatetpye').click(function (e) {
                typeid = this.id.substr(6);
                
                $.each(types, function(i, v) {
                    if (v.Id == typeid) {
                        $("#typeName").val(v.Name);
                        return ;
                    }
                });
                ShowTypeDialog();
            });

        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}

function ShowSubTypes() {
    subtypeid = -1;
    $("#placeholderSubType").setTemplateURL('Templates/SubType1.htm', null, { filter_data: false });
    $("#placeholderSubType").processTemplate(subtypes);
    $('.deletesubtpye').click(function (e) {
        DeleteSubType(this.id.substr(9));
    });
    $('.activatesubtpye').click(function (e) {
        ActivateSubType(this.id.substr(11));
    });
    $('.updatesubtpye').click(function (e) {
        subtypeid = this.id.substr(9);
                
        $.each(subtypes, function(i, v) {
            if (v.Id == subtypeid) {
                $("#subTypeName").val(v.Name);
                return ;
            }
        });
        ShowSubTypeDialog();
    });
}

function GetSubTypes() {
    $.ajax({
        type: "POST",
        url: pageName + "/GetTypes",
        data: null,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            types = data.d;
             $.each(types, function(i, v) {
                if (v.Id == typeid) {
                    subtypes = v.SubType;
                    ShowSubTypes();
                    return ;
                }
            });
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}

function DeleteType(id) {
    var parameters = "{" + "id:" + id + "}";
    $.ajax({
        type: "POST",
        url: pageName + "/DeleteType",
        data: parameters,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            GetTypes();
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}

function DeleteSubType(id) {
    var parameters = "{" + "id:" + id + "}";
    $.ajax({
        type: "POST",
        url: pageName + "/DeleteSubType",
        data: parameters,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            GetSubTypes();
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}

function ActivateType(id) {
    var parameters = "{" + "id:" + id + "}";
    $.ajax({
        type: "POST",
        url: pageName + "/ActivateType",
        data: parameters,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            GetTypes();
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}

function ActivateSubType(id) {
    var parameters = "{" + "id:" + id + "}";
    $.ajax({
        type: "POST",
        url: pageName + "/ActivateSubType",
        data: parameters,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            GetSubTypes();
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}

function SaveType() {
    var parameters = "{" + "id:" + typeid + ", name:'" + $("#typeName").val() + "'}";
    $.ajax({
        type: "POST",
        url: pageName + "/SaveType",
        data: parameters,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            GetTypes();
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}

function SaveSubType() {
    var parameters = "{" + "id:" + subtypeid + "," + "typeId:" + typeid + "," + " name:'" + $("#subTypeName").val() + "'}";
    $.ajax({
        type: "POST",
        url: pageName + "/SaveSubType",
        data: parameters,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            GetSubTypes();
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}

function ShowTypeDialog() {
     $("#dialogType").dialog({
                    buttons:
                    { 
                        "Ment": function () 
                        {
                            SaveType();
                            $(this).dialog("close");
                        },
                        "Mégsem": function () 
                        {
                            $(this).dialog("close");
                        }
                    }
                });
}

function ShowSubTypeDialog() {
    $("#dialogSubType").dialog({
        buttons:
            {
                "Ment": function() {
                    SaveSubType();
                    $(this).dialog("close");
                },
                "Mégsem": function() {
                    $(this).dialog("close");
                }
            }
    });
}