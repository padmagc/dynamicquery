﻿/**/
var datamoduleQuery = '';
var datamoduleTable = '';
var datamoduleType = '';
var ddlTable = '';
var ddlColumnType = '';
var ddlColumnSubType = '';
/**/
var gridSavedQueries = '';
var gridColumns = '';
var actualQuery = {};
var sqlfilter = {};
function InitFormSpec() {
    $('#m').stepy({
        finishButton: false,
        backLabel: 'Vissza',
        nextLabel: 'Előre',
        titleClick: true,
        select: function (index) {
            SelectStep(index);
        }
    });
    $('#dialogFilter').hide();
    $('#dialogOrderBy').hide();
    sqlfilter = new xFilter(document.getElementById("filters"),
    {
        columns: []
    });
    /***/
    SetControlsToBase();
    BindEvents();
    /***/
    gridSavedQueries = new DQ.Grid();
    gridSavedQueries.Init($('#placeholderQuery'), $("#queryRowPlaceholder"), $("#queryRowTemplate"), gridSavedQueriesGridFunction);

    gridColumns = new DQ.Grid();
    gridColumns.Init($('#placeholderColumns'), $("#columnRowPlaceholder"), $("#columnRowTemplate"), gridColumnsFunction);

    ddlTable = new DQ.DropDown($('#Table'), 'Id', 'Name');
    ddlColumnType = new DQ.DropDown($('#ColumnType'), 'Id', 'Name');
    ddlColumnSubType = new DQ.DropDown($('#ColumnSubType'), 'Id', 'Name');
    /***/
    datamoduleQuery = new DQ.Query();
    datamoduleQuery.GetQueries(Callback_QueryGetQueries);
    /***/
    datamoduleTable = new DQ.Field();
    datamoduleTable.getTables(Callback_QueryGetTable);
    /***/
    datamoduleType = new DQ.FieldType();
    datamoduleType.getType(Callback_QueryGetType);
}
/*************************************************/
/*************** Callbacks ***********************/
/*************************************************/
/*
 * Mentett lekérdezések betöltése
 */
function Callback_QueryGetQueries(data) {
    gridSavedQueries.SetDatasource(data);
}
/*
* Táblák lekérdezése
*/
function Callback_QueryGetTable(data) {
    ddlTable.Init(data);
    ddlTable.OnChange(Event_ChangeTable);
}
/*
* Oszlop típusok lekérdezése
*/
function Callback_QueryGetType(data) {
    ddlColumnType.Init(data);
    ddlColumnType.OnChange(Event_ChangeColumnType);
}
/*
* Oszlop altípusok lekérdezése
*/
function Callback_QueryGetSubType(data) {
    ddlColumnSubType.Init(data);
    ddlColumnSubType.OnChange(Event_ChangeColumnSubType);
}
/*
* Adatok újratöltése
*/
function Callback_ReloadQueries(data) {
    $('#m').stepy('step', 1);
    SetControlsToBase();
    datamoduleQuery.GetQueries(Callback_QueryGetQueries);
}
/*
* Mentett lekérdezés adatok betöltése
*/
function Callback_LoadSelectedQuery(data) {
    SetControlsToBase(data);
    $('#m').stepy('step', 2);
}
/*
* Tábla oszlopainak betöltése, kalkulált mezők is
*/
function Callback_ShowColumns(data) {
    var columns = [];
    var other = '';
    var selected = false;
    if (data != null) {
        // base columns of table
        $.each(data.Columns, function (i, v) {
            other = v.ColumnType;
            if (v.Length != 0) {
                other += '(' + v.Length;
                if (v.DecimalLength != 0) {
                    other += ',' + v.DecimalLength;
                }
                other += ')';
            }

            // Ellenőrzés hogy már hozzá lett e adva a query - hez
            var e = actualQuery.Columns.filter(function(element) { return element.Calculated == false && element.ColumnId == v.Id; });
            var o = false;
            if(e.length > 0 && e[0].IsOrderBy == true) {
                o = true;
            }
            columns.push({
                Id: v.Id,
                Name: v.Name,
                Description: v.Description,
                Other: other,
                Active: v.Active,
                Calculated: false,
                Selected: e.length > 0,
                Sql: '[' + ddlTable.GetText() + '].[' + v.Name + '] AS ' + v.Name,
                Table: ddlTable.GetText(),
                ColumnType: v.ColumnType,
                IsOrderBy: o
            });
        });
        $.each(data.CalculatedColumns, function (i, v) {
            other = '';
            if (v.GroupBy) {
                other = '(GroupBy)';
            }
            other += ' ' + v.Sql;

            var ec = actualQuery.Columns.filter(function (element) { return element.Calculated == true && element.ColumnId == v.Id; });

            columns.push({
                Id: v.Id,
                Name: '(C)' + v.Name,
                Description: v.Description,
                Other: other,
                Active: v.Active,
                Calculated: true,
                Selected: ec.length > 0,
                Sql: v.Sql,
                Table: ddlTable.GetText(),
                ColumnType: '',
                IsOrderBy: false
            });
        });
    }
    gridColumns.SetDatasource(columns);
}
/*************************************************/
/*************** Events **************************/
/*************************************************/
/*
* Tábla választása
*/
function Event_ChangeTable(data) {
    datamoduleTable.GetAllField(Callback_ShowColumns, ddlTable.GetValue(), ddlColumnType.GetValue(), ddlColumnSubType.GetValue());
}
/*
* Típus választása
* - altípusok betöltése
* - oszlopok szűrése
*/
function Event_ChangeColumnType(data) {
    datamoduleType.getSubType(data, Callback_QueryGetSubType);
    datamoduleTable.GetAllField(Callback_ShowColumns, ddlTable.GetValue(), ddlColumnType.GetValue(), ddlColumnSubType.GetValue());
}
/*
* Altípus választása
* - oszlopok szűrése
*/
function Event_ChangeColumnSubType(data) {
    datamoduleTable.GetAllField(Callback_ShowColumns, ddlTable.GetValue(), ddlColumnType.GetValue(), ddlColumnSubType.GetValue());
}
/*************************************************/
/*************** Functions ***********************/
/*************************************************/
/*
* Az ablakon található beviteli kontolok alap állapotba állítása
* valamint az ablakon használt lokális változók adatainak törlése
*/
function SetControlsToBase(data) {
    if (data == null || data === 'undefined') {
        actualQuery = {
            Id: -1,
            Name: '',
            Description: '',
            Columns: []
        };
    } else {
        actualQuery = {
            Id: data.Id,
            Name: data.Name,
            Description: data.Description,
            Columns: data.Columns
        };
    }

    $('#QueryName').val(actualQuery.Name);
    $('#QueryDescription').val(actualQuery.Description);
    $('#queryDataResult').html('');
    if (ddlTable != '') ddlTable.SetIndex(-1);
    if (ddlColumnType != '') ddlColumnType.SetIndex(-1);
    if (ddlColumnSubType != '') ddlColumnSubType.SetIndex(-1);
}
/*
* Adatok mentéshez való frissítése
*/
function RefreshDTO() {
    actualQuery.Name = $('#QueryName').val();
    actualQuery.Description = $('#QueryDescription').val();
}
/*
* Az ablakon található vezérlők eseményei
*/
function BindEvents(functionname, data) {
    $('#newQuery').click(function (e) {
        SetControlsToBase();
        $('#m').stepy('step', 2);
        e.preventDefault();
    });
    $('#saveQuery').click(function (e) {
        e.preventDefault();
        // Adat szinkronizáció
        RefreshDTO();
        if (actualQuery.Id == -1) {
            datamoduleQuery.NewQuery(actualQuery, Callback_ReloadQueries);
        } else {
            datamoduleQuery.UpdateQuery(actualQuery, Callback_ReloadQueries);
        }
    });
}
/*
* Mentett lekérdezések gridben található funkciók 'gombok' eseményei
*/
function gridSavedQueriesGridFunction(functionname, data) {
    Utils.logToConsole("Call " + functionname + " method", data.Id);
    switch (functionname) {
        case 'inactive':
            datamoduleQuery.SetStatus(data.Id, Callback_ReloadQueries);
            break;
        case 'active':
            datamoduleQuery.SetStatus(data.Id, Callback_ReloadQueries);
            break;
        case 'load':
            datamoduleQuery.GetQuery(data.Id, Callback_LoadSelectedQuery);
            break;            
        default:
            Utils.logToConsole('Warning', 'Unknown function called');
    }
}
/*
* Tábla mezők gridben található funkciók 'gombok' eseményei
*/
function gridColumnsFunction(functionname, data) {
    Utils.logToConsole("Call " + functionname + " method", data.Id);
    switch (functionname) {
        case 'addcolumn':
            actualQuery.Columns.push({
                TableId: ddlTable.GetValue(),
                TableName: ddlTable.GetText(),
                ColumnId: data.Id,
                ColumnName: data.Name,
                Calculated: data.Calculated,
                IsSelected: true,
                IsOrderBy: false,
                Direction: null,
                Position: null
            });
            datamoduleTable.GetAllField(Callback_ShowColumns, ddlTable.GetValue(), ddlColumnType.GetValue(), ddlColumnSubType.GetValue());
            break;
        case 'removecolumn':
            actualQuery.Columns = actualQuery.Columns.filter(function (element) { return element.ColumnId != data.Id; });
            datamoduleTable.GetAllField(Callback_ShowColumns, ddlTable.GetValue(), ddlColumnType.GetValue(), ddlColumnSubType.GetValue());
            break;
        case 'addorderby':
            $("#dialogOrderBy").dialog({
                buttons:
                {
                    "Mégsem": function () {
                        $(this).dialog("close");
                    },
                    "Bezár": function () {
                        var oc = actualQuery.Columns.filter(function (element) { return element.ColumnId == data.Id; });
                        oc[0].IsOrderBy = true;
                        oc[0].Direction = $('#OrderByDirection').val();
                        oc[0].Position = null;
                        $(this).dialog("close");
                        datamoduleTable.GetAllField(Callback_ShowColumns, ddlTable.GetValue(), ddlColumnType.GetValue(), ddlColumnSubType.GetValue());
                    }
                }
            });
            break;
        case 'removeorderby':
            var c = actualQuery.Columns.filter(function (element) { return element.ColumnId != data.Id; });
            c.IsOrderBy = false;
            c.Direction = null;
            c.Position = null;
            break;
        case 'where':
            sqlfilter.columns.push({
                "name": data.Name,
                "index": data.Id,
                "table" : ddlTable.GetText()
            });
            sqlfilter.reDraw();
            $("#dialogFilter").dialog({
                buttons:
                {
                    "Bezár": function () {
                        $(this).dialog("close");
                    }
                }
            });
            break;
        default:
            Utils.logToConsole('Warning', 'Unknown function called');
    }
}
/*
* 'Lépés' események
* Az utolsó oldalon a lekérdezés adatainak kiírása
*/
function SelectStep(index) {
    if (index == 4) {
        var html = '<b>Lekérdezés neve :</b> {0}<br />' +
                    '<b>Lekérdezés leírása :</b> {1}<br />' +
                    '<br />' +
                    '<br />' +
                    '<b>Lekérdezés :</b>' +
                    '<br />' +
                    '{2}'
                    ;
        $('#queryDataResult').html('');
        $('#queryDataResult').append(
            html.toString()
                .replace('{0}', $('#QueryName').val())
                .replace('{1}', $('#QueryDescription').val())
                .replace('{2}', '...')
        );
    }
}