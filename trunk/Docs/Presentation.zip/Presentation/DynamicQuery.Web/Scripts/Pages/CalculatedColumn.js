﻿var pageName = "CalculatedColumn.aspx";
var datamodulecolumn = '';
var datamoduledialogcolumn = '';
var datamodulecolumntype = '';
var datamoduleSQL = '';
var ddltable = '';
var ddldialogtable = '';
var ddldialogcolumn = '';
var ddlsql = '';
var ddltype = '';
var ddlsubtype = '';
var grid = '';
var selecteddata = '';
var calculatedSQLTables = [];
/************************************************/
function InitFormSpec() {
    InitDataModules();
}
function InitDataModules() {
    $.localStorage.removeItem(CONST_Table);
    $.localStorage.removeItem(CONST_DialogTable);
    /**/
    ddltype = new DQ.DropDown($('#ColumnType'), "Id", "Name");
    ddlsubtype = new DQ.DropDown($('#ColumnSubType'), "Id", "Name");
    /**/
    datamoduleSQL = new DQ.Sql();
    datamoduleSQL.init();
    /**/
    datamodulecolumn = new DQ.CalculatedColumn();
    datamodulecolumn.getTables(CallBack_GetTable);
    /**/
    datamodulecolumntype = new DQ.FieldType();
    datamodulecolumntype.getType(CallBack_GetType);
    /**/
    /**/
    grid = new DQ.Grid();
    grid.Init($('#placeholderColumn'), $("#rowPlaceholder"), $("#rowTemplate"), GridFunction);
    /**/
    $('#saveColumn').click(function () {
        var d = refreshdto();
        if (d.Id == -1) {
            datamodulecolumn.newColumn(d, Callback_NewColumn);
        } else {
            datamodulecolumn.updateColumn(d, Callback_UpdateColumn);
        }
        setDefault();
    });
    $('#newColumn').click(function () {
        setDefault();
        selecteddata = createdto(null);
    });
    $('#cancelColumn').click(function () {
        setDefault();
    });
    /* DIALOG */
    $('#generateSQL').click(function () {
        $("#dialogBuilder").dialog({
            buttons:
                    {
                        "Ment": function () {
                            $('#ColumnSQL').val($('#builderSQL').val() + ' AS ' + $('#builderColumnName').val());
                            $(this).dialog("close");
                        },
                        "Mégsem": function () {
                            $(this).dialog("close");
                        }
                    }
        });
    });
    $("#dialogBuilder").hide();
    
}
/*************************************************/
/*************** Callbacks ***********************/
/*************************************************/
function CallBack_GetTable(data) {
    ddltable = new DQ.DropDown($('#Tables'), "Id", "Name");
    ddltable.Init(data);
    ddltable.OnChange(Event_ChangeTable);

    datamoduledialogcolumn = new DQ.Field();
    datamoduledialogcolumn.setStorageKey(CONST_DialogTable);
    datamoduledialogcolumn.getTables(Callback_GetDialogColumns);

    ddlsql = new DQ.DropDown($("#builderSQLOperators"), "Name", "Description");
    ddlsql.Init(datamoduleSQL.getFunctions());
    ddlsql.OnChange(Event_ChangeOperator);
}
function CallBack_GetType(data) {
    ddltype.Init(data);
    ddltype.OnChange(Event_ChangeType);
}
function CallBack_GetSubType(data) {
    ddlsubtype.Init(data);
}
function CallBack_ShowColumnsCallback(data) {
    grid.SetDatasource(data);
}
function CallBack_ShowDialogColumnsCallback(data) {
    ddldialogcolumn = new DQ.DropDown($('#builderColumn'), "Id", "Name");
    ddldialogcolumn.Init(data);
}
function Callback_InactivateColumn(data) {
    datamodulecolumn.getCalulcatedColumns(CallBack_ShowColumnsCallback, ddltable.GetValue());
}
function Callback_UpdateColumn(data) {
    datamodulecolumn.getCalulcatedColumns(CallBack_ShowColumnsCallback, ddltable.GetValue());
}
function Callback_NewColumn(data) {
    datamodulecolumn.getCalulcatedColumns(CallBack_ShowColumnsCallback, ddltable.GetValue());
}
function Callback_GetDialogColumns(data) {
    ddldialogtable = new DQ.DropDown($('#builderTable'), "Id", "Name");
    ddldialogtable.Init(data);
    ddldialogtable.OnChange(Event_ChangeDialogTable);

}
/*************************************************/
/*************** Functions ***********************/
/*************************************************/
function GridFunction(functionname, data) {
    Utils.logToConsole("Call " + functionname + " method", data.Id);
    switch (functionname) {
        case 'inactive':
            datamodulecolumn.setStatus(data.Id, Callback_InactivateColumn);
            break;
        case 'active':
            datamodulecolumn.setStatus(data.Id, Callback_UpdateColumn);
            break;
        case 'update':
            selecteddata = createdto(data);
            showSelectedColumnData(data);
            break;
        default:
            Utils.logToConsole('Warning', 'Unknown function called');
    }
}
function createdto(data) {
    var columnData = {};
    if (data == null) {
        columnData['Id'] = -1;
        columnData['Sql'] = '';
        columnData['Name'] = '';
        columnData['Description'] = '';
        columnData['Type'] = -1;
        columnData['SubType'] = -1;
    } else {
        columnData['Id'] = data.Id;
        columnData['Sql'] = data.TableNameAndColumnName;
        columnData['Name'] = data.Name;
        columnData['Description'] = data.Description;
        columnData['Type'] = data.Type;
        columnData['SubType'] = data.SubType;
    }
    columnData['CalculatedField'] = true;
    return columnData;
}
function refreshdto() {
    var columnData = {};
    columnData['Id'] = selecteddata.Id;
    columnData['Sql'] = $('#ColumnSQL').val();
    columnData['Name'] = $('#ColumnName').val();
    columnData['Description'] = $('#ColumnDescription').val();
    columnData['Type'] = ddltype.GetValue();
    columnData['SubType'] = ddlsubtype.GetValue();
    columnData['TableId'] = ddltable.GetValue();
    columnData['CalculatedField'] = true;
    var t = [];
    for (var index = 0; index < calculatedSQLTables.length; index++ ) {
        if(calculatedSQLTables[index].Counter > 0) {
            t.push({ Id: calculatedSQLTables[index].Id });
        }
    }
    columnData['Tables'] = t;
    return columnData;
}
function showSelectedColumnData(data) {
    setDefault();
    $("#ColumnName").val(data.Name);
    $("#ColumnDescription").val(data.Description);
    $("#ColumnSQL").val(data.Sql);
    $("#builderColumnName").val(data.Sql.substring(data.Sql.indexOf("AS") + 2));
    $("#builderSQL").val(data.Sql.substring(0,data.Sql.indexOf("AS")));
    if (data.Type != 'undefined' && data.Type != null) {
        ddltype.SetSelectedValue(data.Type);
        // TODO
    }
    if (data.SubType != 'undefined' && data.SubType != null) {
        ddlsubtype.SetSelectedValue(data.SubType);
    }
    for (var index = 0; data.Tables.length > index; index++) {
        calculatedSQLTables.push({ Id: data.Tables[index].Id, Table: data.Tables[index].Name, Counter: 1 });
    }
    selecteddata = data;
}
function setDefault() {
    $("#builderColumnName").val('');
    $("#builderSQL").val('');
    $("#ColumnName").val('');
    $("#ColumnDescription").val('');
    $("#ColumnSQL").val('');
    ddltype.SetIndex(-1);
    selecteddata = '';
    calculatedSQLTables = [];
}
/*************************************************/
/*************** Events **************************/
/*************************************************/
function Event_ChangeDialogTable(data) {
    datamoduledialogcolumn.getFields(CallBack_ShowDialogColumnsCallback, data);
}
function Event_ChangeOperator(data) {
    var range = $('#builderSQL').getSelection();
    var text = '';
    var found = false;
    var i = 0;
    if (ddldialogtable.GetValue() != -1
        &&
            (ddldialogcolumn.GetValue() != -1
                ||
             (ddlsql.GetValue() != -1 && datamoduleSQL.getSQLFunction(ddlsql.GetValue()).WorkWithSelection && range.length > 0)
            )
        ) {
        var actualText = $('#builderSQL').val();
        if (ddlsql.GetValue() != 'REMOVE') {
            var f = datamoduleSQL.getSQLFunction(ddlsql.GetValue());
            if (f != null) {
                if (range.length == 0) {
                    text = [actualText.slice(0, range.start), ' ' + f.ReplaceText.replace('{0}', ddldialogtable.GetText() + '.' + ddldialogcolumn.GetText()), actualText.slice(range.start)].join('');
                } else {
                    text = [actualText.slice(0, range.start), ' ' + f.ReplaceText.replace('{0}', actualText.substring(range.start, range.end)), actualText.slice(range.end)].join('');
                }
                for (i = 0; i < calculatedSQLTables.length; i++) {
                    if (calculatedSQLTables[i].Table == ddldialogtable.GetText()) {
                        calculatedSQLTables[i].Counter++;
                        found = true;
                    }
                }
                if (!found) {
                    calculatedSQLTables.push({ Id: ddldialogtable.GetValue(), Table: ddldialogtable.GetText(), Counter: 1 });
                }
            }
        } else {
            text = [actualText.slice(0, range.start), '', actualText.slice(range.end)].join('');
            for (i = 0; i < calculatedSQLTables.length; i++) {
                if (calculatedSQLTables[i].Table == ddldialogtable.GetText()) {
                    calculatedSQLTables[i].Counter--;
                }
            }
        }
        $('#builderSQL').val(text);
        ddldialogcolumn.SetIndex(-1);
        ddlsql.SetIndex(-1);
    }
}

function Event_ChangeTable(data) {
    datamodulecolumn.getCalulcatedColumns(CallBack_ShowColumnsCallback, data);
    ddldialogtable.SetSelectedValue(ddltable.GetValue());
}
function Event_ChangeType(data) {
    if (ddlsubtype != 'undefined') {
        ddlsubtype.Clear();
    }
    datamodulecolumntype.getSubType(data, CallBack_GetSubType);
}
