﻿// Fő javascript file, minden oldal alapja!
function InitForm() {
    // Minden oldalnak implementalni kell egy sajat javascript filet, oda lehet betenni az oldal specifikus hívasokat
    // Fontos az elnevezes is
    InitFormSpec();
}