﻿var pageName = "Fields.aspx";
var datamodulefield = '';
var datamodulefieldtype = '';
var ddltable = '';
var ddltype = '';
var ddlsubtype = '';
var grid = '';
var selecteddata = '';
/************************************************/
function InitFormSpec() {
    InitDataModules();
}
function InitDataModules() {
    /**/
    datamodulefield = new DQ.Field();
    datamodulefield.getTables(CallBack_SuccessGetTable);
    /**/
    datamodulefieldtype = new DQ.FieldType();
    datamodulefieldtype.getType(CallBack_SuccessGetType);
    /**/
    grid = new DQ.Grid();
    grid.Init($('#placeholderField'), $("#rowPlaceholder"), $("#rowTemplate"), GridFunction);
    /**/
    ddltype = new DQ.DropDown($('#FieldType'), "Id", "Name");
    ddlsubtype = new DQ.DropDown($('#FieldSubType'), "Id", "Name");
    /**/
    $('#saveField').click(function () {
        // TODO validation
        datamodulefield.updateField(createdto(selecteddata), Callback_UpdateField);
        setDefault();
    });
    $('#cancelField').click(function () {
        setDefault();
    });
}
/*************************************************/
/*************** Callbacks ***********************/
/*************************************************/
function CallBack_SuccessGetTable(data) {
    ddltable = new DQ.DropDown($('#Tables'), "Id", "Name");
    ddltable.Init(data);
    ddltable.OnChange(Event_ChangeTable);
}
function CallBack_SuccessGetType(data) {
    ddltype.Init(data);
    ddltype.OnChange(Event_ChangeType);
}
function CallBack_GetSubType(data) {
    ddlsubtype.Init(data);
}

function CallBack_ShowColumnsCallback(data) {
    grid.SetDatasource(data);
}
function Callback_InactivateField(data) {
    datamodulefield.getFields(CallBack_ShowColumnsCallback, ddltable.GetValue());
}
function Callback_UpdateField(data) {
    datamodulefield.getFields(CallBack_ShowColumnsCallback, ddltable.GetValue());
}
/*************************************************/
/*************** Functions ***********************/
/*************************************************/
function GridFunction(functionname, data) {
    Utils.logToConsole("Call " + functionname + " method", data.Id);
    switch (functionname) {
        case 'inactive':
            datamodulefield.inactiveField(data.Id, Callback_InactivateField);
            break;
        case 'active':
            datamodulefield.updateField(createdto(data), Callback_UpdateField);
            break;
        case 'update':
            showSelectedColumnData(data);
            //datamodulefield.updateField(createdto(data), Callback_UpdateField);
            break;
        default:
            Utils.logToConsole('Warning', 'Unknown function called');
    }
}
function createdto(data) {
    var columnData = {};
    columnData['Id'] = data.Id;
    columnData['TableNameAndColumnName'] = '';
    columnData['Name'] = data.Name;
    columnData['Description'] = data.Description;
    columnData['Type'] = ddltype.GetValue();
    columnData['SubType'] = ddlsubtype.GetValue();
    columnData['ColumnType'] = data.ColumnType;
    columnData['Length'] = data.Length;
    columnData['DecimalLength'] = data.DecimalLength;
    columnData['Active'] = true;
    columnData['CalculatedField'] = false;
    columnData['TableId'] = ddltable.GetValue();
    return columnData;
}
function showSelectedColumnData(data) {
    setDefault();
    $("#FieldName").val(data.Name);
    $("#FieldDescription").val(data.Description);
    if(data.Type != 'undefined' && data.Type != null) {
        ddltype.SetSelectedValue(data.Type);
    }
    if (data.SubType != 'undefined' && data.SubType != null) {
        ddlsubtype.SetSelectedValue(data.SubType);
    }
    selecteddata = data;
}
function setDefault()
{
    $("#FieldName").val('');
    $("#FieldDescription").val('');
    ddltype.SetIndex(-1);
    selecteddata = '';
}
/*************************************************/
/*************** Events **************************/
/*************************************************/
function Event_ChangeTable(data) {
    datamodulefield.getFields(CallBack_ShowColumnsCallback, data);
}
function Event_ChangeType(data) {
    if (ddlsubtype != 'undefined') {
        ddlsubtype.Clear();
    }
    datamodulefieldtype.getSubType(data, CallBack_GetSubType);
}
