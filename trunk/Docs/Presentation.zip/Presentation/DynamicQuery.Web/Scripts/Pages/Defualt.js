﻿function InitFormSpec() {
}