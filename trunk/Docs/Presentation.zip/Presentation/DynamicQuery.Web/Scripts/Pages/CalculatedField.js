﻿var pageName = "CalculatedField.aspx";
var tables = '';
var types = '';
function InitFormSpec() {
    GetTables();
    GetTypes();
}

function GetTables() {
    $.ajax({
        type: "POST",
        url: pageName + "/GetTables",
        data: null,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            $('#Tables').html('');
            var tablesOutput = [];
            tablesOutput.push('<option value="-1">Válassz...</option>');
            tables = data.d;
            $.each(data.d, function (key, value) {
                tablesOutput.push('<option value="' + value.Id + '">' + value.Name + '</option>');
            });
            $('#Tables').html(tablesOutput.join(''));
            $('#Tables').change(function () {
                ShowFields($('#Tables').val());
            });
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}

function GetTypes() {
    $.ajax({
        type: "POST",
        url: pageName + "/GetTypes",
        data: null,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            $('#FieldType').html('');
            var typesOutput = [];
            typesOutput.push('<option value="-1">Válassz...</option>');
            types = data.d;
            $.each(data.d, function (key, value) {
                typesOutput.push('<option value="' + value.Id + '">' + value.Name + '</option>');
            });
            $('#FieldType').html(typesOutput.join(''));
            ShowSubTypes($('#FieldType').val());
            
            $('#FieldType').change(function () {
                ShowSubTypes($('#FieldType').val());
            });
            
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}

function ShowFields(id) {
    $("#placeholderFields").html('');
    if (id > 0) {
        $.each(tables, function (i, v) {
            if (v.Id == id) {
                $("#placeholderFields").setTemplateURL('Templates/Fields.html', null, { filter_data: false });
                $("#placeholderFields").processTemplate(v.Columns);
                BindGridEvents();
            }
        });
        $("#fieldproperties").css("visibility", "visible");
        $('#CalculatedFieldName').val('');
        $('#CalculatedFieldDescription').val('');
        $('#CalculatedFieldSQL').val('');
        $('#FieldType').val(-1);
        ShowSubTypes($('#FieldType').val());
    } else {
        $("#fieldproperties").css("visibility", "hidden");
    }
}
function ShowSubTypes(id) {
    $('#FieldSubType').html('');
    var subtypesOutput = [];
    subtypesOutput.push('<option value="-1">Válassz...</option>');

    $.each(types, function (i, v) {
        if (v.Id == id) {
            $('#FieldSubType').html('');
            $.each(v.SubType, function (key, value) {
                subtypesOutput.push('<option value="' + value.Id + '">' + value.Name + '</option>');
            });
        }
    });
    $('#FieldSubType').html(subtypesOutput.join(''));
}

function BindGridEvents() {
    $('.update').click(function (e) {

    });
    $('.activate').click(function (e) {
        ActivateRecord(this.id.substr(8), this.name == 'true');
    });
    $('.unactivate').click(function (e) {
        InactivateRecord(this.id.substr(10), this.name == 'true');
    });
}
function CreateDTO(id, calculatedField) {
    var columnData = {};
    columnData['Id'] = id;
    columnData['TableNameAndColumnName'] = $('#CalculatedFieldSQL').val();
    columnData['Name'] = $('#CalculatedFieldName').val();
    columnData['Description'] = $('#CalculatedFieldDescription').val();
    columnData['Type'] = $('#FieldType').val();
    columnData['SubType'] = $('#FieldSubType').val();
    columnData['ColumnType'] = '';
    columnData['Length'] = 0;
    columnData['DecimalLength'] = 0;
    columnData['CalculatedField'] = calculatedField;
    columnData['Active'] = true;
    columnData['TableId'] = $('#Tables').val();
    return columnData;
}

function ActivateRecord(id, calculatedField) {
    var actionUrl = '';
    if(calculatedField == true) {
        actionUrl = pageName + "/UpdateCalculatedField";
    } else {
        actionUrl = pageName + "/UpdateField";
    }
    var dto = { 'column': CreateDTO(id, calculatedField) };
    
    $.ajax({
        type: "POST",
        url: actionUrl,
        data: JSON.stringify(dto),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            ShowFields($('#Tables').val());
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}
function InactivateRecord(id, calculatedField) {
    var actionUrl = '';
    if (calculatedField == true) {
        actionUrl = pageName + "/DeleteCalculatedField";
    } else {
        actionUrl = pageName + "/DeleteField";
    }

    var dto = { 'column': CreateDTO(id, calculatedField) };

    $.ajax({
        type: "POST",
        url: actionUrl,
        data: JSON.stringify(dto),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            ShowFields($('#Tables').val());
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}