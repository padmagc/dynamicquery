﻿var pageName = "Documentation.aspx";
var tables = '';
var generatedTables = [];
function InitFormSpec() {
    $("#generate").click(function () {
        Generator();
    });
}

function Generator() {
    // Get table names
    $.ajax({
        type: "POST",
        url: pageName + "/GetTables",
        data: null,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            $('#result').html('');
            tables = data.d;
            // Generator
            $.each(tables, function (idx, obj) {
                GenerateDocumentation(obj);
            });
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });

}
function GenerateDocumentation(tableName) {
    var parameters = "{" + "tableName:'" + tableName + "'}";
    // Get table names
    $.ajax({
        type: "POST",
        url: pageName + "/GenerateDocumentation",
        data: parameters,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: (function success(data, status) {
            // TODO progressbar
            $('#result').append(data.d + '<br />');
        }),
        error: (function Error(request, status, error) {
            // Hiba
            alert(request.statusText);
        })
    });
}