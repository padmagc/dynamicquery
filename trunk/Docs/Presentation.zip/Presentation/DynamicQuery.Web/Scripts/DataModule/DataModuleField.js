﻿var DQ = DQ || {};

DQ.Field = function () {
    var 
    /********** Variables **********/
        className = 'DQ.Field',
        url = "Services/TablesAndFields.asmx/",
        columnConstans = CONST_Table,
    /********** GET field types **********/
        getFields = function (callback, tableId) {
            var tables;
            if (!$.localStorage.getItem(columnConstans)) {
                Utils.logToConsole(className, 'get table data from database');
                $.ajax({
                    type: "POST",
                    url: url + 'GetTables',
                    data: null,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (data) {
                        $.localStorage.setItem(columnConstans, data.d);
                        callback(searchTable(data.d, tableId));
                    },
                    error: (function (response, status, error) {
                        Utils.errorlog(className, response.statusText);
                    })
                });
            } else {
                Utils.logToConsole(className, 'get table data from cache');
                /* Search colums */
                callback(searchTable($.localStorage.getItem(columnConstans), tableId));
            }
        },
        getAllField = function (callback, tableId, typeId, subTypeId) {
            if (!$.localStorage.getItem(columnConstans)) {
                Utils.logToConsole(className, 'get table data from database');
                $.ajax({
                    type: "POST",
                    url: url + 'GetTables',
                    data: null,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (data) {
                        $.localStorage.setItem(columnConstans, data.d);
                        callback(collectData(data.d, tableId, typeId, subTypeId));
                    },
                    error: (function (response, status, error) {
                        Utils.errorlog(className, response.statusText);
                    })
                });
            } else {
                Utils.logToConsole(className, 'get table data from cache');
                /* Search colums */
                callback(collectData($.localStorage.getItem(columnConstans), tableId, typeId, subTypeId));
            }
        },
        searchTable = function (tables, id) {
            var columns = null;
            $.each(tables, function (i, v) {
                if (v.Id == id) {
                    columns = v.Columns;
                }
            });
            return columns;
        },
        collectData = function (tables, id, typeId, subTypeId) {
            var t = tables.filter(function (element) { return element.Id == id; })[0];
            if(t == null || t === 'undefined') return null;

            var records = {
                Id: id,
                Columns: t.Columns.filter(function (element) {
                    if (typeId == -1) {
                        return true;
                    } else {
                        if (subTypeId > -1) {
                            return element.Type == typeId && element.SubType == subTypeId;
                        } else {
                            return element.Type == typeId;
                        }
                    }
                }),
                CalculatedColumns: t.CalculatedColumns.filter(function (element) {
                    if (typeId == -1) {
                        return true;
                    } else {
                        if (subTypeId > -1) {
                            return element.Type == typeId && element.SubType == subTypeId;
                        } else {
                            return element.Type == typeId;
                        }
                    }
                })
            };
            return records;
        },
        setStorageKey = function (key) {
            columnConstans = key;
        },
        inactiveField = function (id, callback) {
            Utils.logToConsole(className, 'inactivate this field : ' + id);
            var parameters = "{" + "fieldId:" + id + "}";
            $.ajax({
                type: "POST",
                url: url + 'InactivateField',
                data: parameters,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    $.localStorage.removeItem(columnConstans);
                    callback(true);
                },
                error: (function (response, status, error) {
                    Utils.errorlog(className, response.statusText);
                })
            });

        },
        updateField = function (dto, callback) {
            Utils.logToConsole(className, 'update this field : ' + dto.Id);
            var parameters = { 'column': dto };
            $.ajax({
                type: "POST",
                url: url + 'UpdateField',
                data: JSON.stringify(parameters),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    $.localStorage.removeItem(columnConstans);
                    callback(true);
                },
                error: (function (response, status, error) {
                    Utils.errorlog(className, response.statusText);
                })
            });
        },
        getTables = function (callback) {
            if (!$.localStorage.getItem(columnConstans)) {
                Utils.logToConsole(className, 'get data from database');
                $.ajax({
                    type: "POST",
                    url: url + 'GetTables',
                    data: null,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (data) {
                        $.localStorage.setItem(columnConstans, data.d);
                        callback(data.d);
                    },
                    error: (function (response, status, error) {
                        Utils.errorlog(className, response.statusText);
                    })
                });
            } else {
                Utils.logToConsole(className, 'get data from cache');
                callback($.localStorage.getItem(columnConstans));
            }
        };
    return {
        getTables: getTables,
        getFields: getFields,
        GetAllField: getAllField,
        inactiveField: inactiveField,
        updateField: updateField,
        setStorageKey: setStorageKey
    };
};