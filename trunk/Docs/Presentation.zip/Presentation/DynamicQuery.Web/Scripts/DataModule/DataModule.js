﻿var DQ = DQ || {};

DQ.FieldType = function () {
    var 
    /********** Variables **********/
        className = 'DQ.FieldType',
        url = "Services/FieldType.asmx/",
    /********** GET field types **********/
    getSubType = function (typeid, callback) {
        if (!$.localStorage.getItem(CONST_FieldType)) {
            Utils.logToConsole(className, 'get data from database');
            $.ajax({
                type: "POST",
                url: url + 'GetTypes',
                data: null,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: (function (data, status) {
                    $.localStorage.setItem(CONST_FieldType, data.d);
                }),
                error: (function (response, status, error) {
                    Utils.errorlog(className, response.statusText);
                })
            });
        }
        $.each($.localStorage.getItem(CONST_FieldType), function (i, v) {
            if (v.Id == typeid) {
                callback(v.SubType);
            }
        });
    },
    getType = function (callback) {
        if (!$.localStorage.getItem(CONST_FieldType)) {
            Utils.logToConsole(className, 'get data from database');
            $.ajax({
                type: "POST",
                url: url + 'GetTypes',
                data: null,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: (function (data, status) {
                    $.localStorage.setItem(CONST_FieldType, data.d);
                    callback(data.d);
                }),
                error: (function (response, status, error) {
                    Utils.errorlog(className, response.statusText);
                })
            });
        } else {
            Utils.logToConsole(className, 'get data from cache');
            callback($.localStorage.getItem(CONST_FieldType));
        }
    };
    return {
        getType: getType,
        getSubType: getSubType
    };
};