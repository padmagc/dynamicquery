﻿var DQ = DQ || {};

DQ.CalculatedColumn = function () {
    var 
    /********** Variables **********/
        className = 'DQ.CalculatedColumn',
        url = "Services/TablesAndFields.asmx/",
    /********** GET field types **********/
        getCalulcatedColumns = function (callback, tableId) {
            var tables;
            if (!$.localStorage.getItem(CONST_Table)) {
                Utils.logToConsole(className, 'get table data from database');
                $.ajax({
                    type: "POST",
                    url: url + 'GetTables',
                    data: null,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (data) {
                        $.localStorage.setItem(CONST_Table, data.d);
                        callback(getColumns(data.d, tableId));
                    },
                    error: (function (response, status, error) {
                        Utils.errorlog(className, response.statusText);
                    })
                });
            } else {
                Utils.logToConsole(className, 'get table data from cache');
                /* Search colums */
                callback(getColumns($.localStorage.getItem(CONST_Table), tableId));
            }
        },
        getColumns = function (tables, id) {
            var columns = null;
            $.each(tables, function (i, v) {
                if (v.Id == id) {
                    columns = v.CalculatedColumns;
                }
            });
            return columns;
        },
        setstatus = function (columnId, callback) {
            Utils.logToConsole(className, 'set activate status on this column : ' + columnId);
            var parameters = "{" + "fieldId:" + columnId + "}";
            $.ajax({
                type: "POST",
                url: url + 'SetStatus',
                data: parameters,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    $.localStorage.removeItem(CONST_Table);
                    callback(true);
                },
                error: (function (response, status, error) {
                    Utils.errorlog(className, response.statusText);
                })
            });

        },
        updateColumn = function (dto, callback) {
            Utils.logToConsole(className, 'update this field : ' + dto.Id);
            var parameters = { 'column': dto };
            $.ajax({
                type: "POST",
                url: url + 'UpdateCalculatedColumn',
                data: JSON.stringify(parameters),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    $.localStorage.removeItem(CONST_Table);
                    callback(true);
                },
                error: (function (response, status, error) {
                    Utils.errorlog(className, response.statusText);
                })
            });
        },
        newColumn = function (dto, callback) {
            Utils.logToConsole(className, 'new calculated column : ' + dto.Id);
            var parameters = { 'column': dto };
            $.ajax({
                type: "POST",
                url: url + 'NewCalculatedColumn',
                data: JSON.stringify(parameters),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    $.localStorage.removeItem(CONST_Table);
                    callback(true);
                },
                error: (function (response, status, error) {
                    Utils.errorlog(className, response.statusText);
                })
            });
        },
        getTables = function (callback) {
            if (!$.localStorage.getItem(CONST_Table)) {
                Utils.logToConsole(className, 'get data from database');
                $.ajax({
                    type: "POST",
                    url: url + 'GetTables',
                    data: null,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (data) {
                        $.localStorage.setItem(CONST_Table, data.d);
                        callback(data.d);
                    },
                    error: (function (response, status, error) {
                        Utils.errorlog(className, response.statusText);
                    })
                });
            } else {
                Utils.logToConsole(className, 'get data from cache');
                callback($.localStorage.getItem(CONST_Table));
            }
        };
    return {
        getTables: getTables,
        getCalulcatedColumns: getCalulcatedColumns,
        newColumn: newColumn,
        updateColumn: updateColumn,
        setStatus: setstatus
    };
};