﻿var CONST_FieldType = 'const_fieldType';
var CONST_Table = 'const_table';
var CONST_Query = 'const_queries';
var CONST_DialogTable = 'const_dialogtable';

var CONST_DEBUGMODE = true;