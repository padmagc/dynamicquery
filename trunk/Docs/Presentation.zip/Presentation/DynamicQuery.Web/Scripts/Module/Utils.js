﻿// Utils Library
// Dependencies: jQuery

window.DQ || (window.DQ = {});    //namespace

DQ.utils = function (window) {
    
};


// Utility függvények, az egész alkalmazásban elérhetőek
// Hívás statikus függvényenként: Utils.formatJSONDate(...);
var Utils = {
    // JSON datatime átalakítása
    formatFromJSONDate: function(jsonDate) {
        var dateString = parseInt(jsonDate.replace("/Date(", "").replace(")/", ""), 10);
        var jsDate = new Date(dateString);
        var newDate = dateFormat(jsDate, "yyyy.mm.dd");
        return newDate;
    },

    // JSON datatime átalakítása
    formatFromJSONDateTime: function(jsonDate) {
        var dateString = parseInt(jsonDate.replace("/Date(", "").replace(")/", ""), 10);
        var jsDate = new Date(dateString);
        var newDate = dateFormat(jsDate, "yyyy.mm.dd hh:MM:ss");
        return newDate;
    },

    // Dátum átalakítása JSON dátummá
    formatToJSONDate: function(jsonDate) {
        if (jsonDate == "") return "";
        if (jsonDate == null) return "";
        var dateString = parseInt(jsonDate.replace("/Date(", "").replace(")/", ""), 10);
        var jsDate = new Date(dateString);
        var newDate = dateFormat(jsDate, "yyyy.mm.dd");
        return newDate;
    },
    // debug módban loggolás
    logToConsole : function(premessage, message) {
        if(CONST_DEBUGMODE) {
            console.log(premessage + '::' + message);
        }
    },
    // debug módban loggolás
    errorlog: function (premessage, message) {
        if (CONST_DEBUGMODE) {
            console.log(premessage + '::' + message);
        }
    }
}