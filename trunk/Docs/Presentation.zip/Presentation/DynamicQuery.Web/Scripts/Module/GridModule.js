﻿var DQ = DQ || {};

DQ.Grid = function () {
    var 
    /********** Variables **********/
        gridId = '',
        tableBodyId = '',
        rowTemplateId = '',
        dataSource = '',
        gridFunctionCallback = '',
        recordCount = 5,
        actualPage = 0,
        pageCount = 0,
    /********** Functions **********/
        setDatasource = function (paramdatasource) {
            /*Utils.logToConsole('setDatasource', 'Add data to ' + tableBodyId.id + ' use ' + rowTemplateId + ' template');*/
            $(gridId).css("visibility", "hidden");
            dataSource = paramdatasource;
            $(tableBodyId).empty();
            if (dataSource != null && dataSource.length != 0) {
                pageCount = Math.ceil(dataSource.length / recordCount);
                if (dataSource.length > (recordCount * pageCount)) {
                    pageCount++;
                }
                bindDatasource();
            } else {
                $.tmpl("<tr id=\"nofound\"><td colspan=\"10\" ><span class=\"NoRecords\">A lekérdezésnek nincs eredménye!</span></td></tr>").appendTo(tableBodyId);
                //$('#rowNotFoundTemplate').tmpl(null).appendTo(tableBodyId);
            }
            $(gridId).css("visibility", "visible");

        },
        bindDatasource = function () {
            $(tableBodyId).empty();
            $(rowTemplateId).tmpl(grepDatasource()).appendTo(tableBodyId);

            if (dataSource.length / recordCount > 1) {
                $.tmpl("<th colspan=\"10\">Oldal : "
                            + "<select id=\"ddPaging\">"
                            + "{{for PageNumber }}"
                            + "{{if ActualPage == $i }}"
                            + "<option value=\"${$i}\" selected=\"selected\">${$i+1}. oldal</option>"
                            + "{{else}}"
                            + "<option value=\"${$i}\">${$i+1}. oldal</option>"
                            + "{{/if}}"
                            + "{{/for}}"
                            + "</select>összesen ${PageNumber} oldal</th>",
                        { "PageNumber": "" + pageCount + "", "ActualPage": "" + actualPage + "" }).appendTo(tableBodyId);
            }

            $(tableBodyId).find('[href]').each(function () {
                $(this).click(function (e) {
                    gridFunctionCallback($(this).attr('class'), $.tmplItem(this).data);
                });
            });

            $('#ddPaging').change(function () {
                pageing();
            });
        },
        grepDatasource = function () {
            var data = [];
            data = jQuery.grep(dataSource, function (d, index) {
                return (index >= actualPage * recordCount && index < (actualPage * recordCount) + recordCount);
            });
            return data;
        },
        pageing = function () {
            actualPage = $("#ddPaging").val();
            Utils.logToConsole("Pageing", actualPage);
            bindDatasource();
        },
        init = function (paramGridId, paramTableBodyId, paramRowTemplateId, paramgridfunction) {
            gridId = paramGridId;
            rowTemplateId = paramRowTemplateId;
            tableBodyId = paramTableBodyId;
            gridFunctionCallback = paramgridfunction;
            actualPage = 0;
            $(gridId).css("visibility", "hidden");
        };
    return {
        Init: init,
        SetDatasource: setDatasource
    };
};
