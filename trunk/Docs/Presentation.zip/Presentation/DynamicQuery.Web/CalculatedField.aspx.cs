﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using DynamicQuery.Logic;

namespace DynamicQuery.Web
{
    public partial class CalculatedField : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) {}

        [WebMethod(true)]
        public static List<Entity.Documentation.DynamicQueryTable> GetTables()
        {
            var t = new TableLogic();
            return t.GetTables();
        }
        [WebMethod(true)]
        public static List<Entity.QueryBuilder.FieldType> GetTypes()
        {
            var f = new FieldTypeLogic();
            return f.GetTypes();
        }
        [WebMethod(true)]
        public static void NewField(Entity.Documentation.DynamicQueryTableColumn column)
        {
            var f = new FieldLogic();
            f.NewField(column);
        }
        [WebMethod(true)]
        public static void NewCalculatedField(Entity.Documentation.DynamicQueryTableColumn column)
        {
            var f = new CalculatedFieldLogic();
            //f.NewCalculatedField(column);
        }
        [WebMethod(true)]
        public static void UpdateField(Entity.Documentation.DynamicQueryTableColumn column)
        {
            var f = new FieldLogic();
            f.UpdateField(column);
        }
        [WebMethod(true)]
        public static void UpdateCalculatedField(Entity.Documentation.DynamicQueryTableColumn column)
        {
            var f = new CalculatedFieldLogic();
            //f.UpdateCalculatedField(column);
        }
        [WebMethod(true)]
        public static void DeleteField(Entity.Documentation.DynamicQueryTableColumn column)
        {
            var f = new FieldLogic();
            f.DeleteField(column.Id);
        }
        [WebMethod(true)]
        public static void DeleteCalculatedField(Entity.Documentation.DynamicQueryTableColumn column)
        {
            var f = new CalculatedFieldLogic();
            //f.DeleteField(column.Id);
        }
    }
}