﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DynamicQuery.Web.Services
{
    public static class ErrorLog
    {
        public static void Log(Exception ex)
        {
            Elmah.ErrorLog.GetDefault(HttpContext.Current).Log(new Elmah.Error(ex, HttpContext.Current));
        }
    }
}