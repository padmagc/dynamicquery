﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using DynamicQuery.Logic;

namespace DynamicQuery.Web.Services
{
    /// <summary>
    /// Summary description for FieldType
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    [System.Web.Script.Services.ScriptService]
    public class FieldType : System.Web.Services.WebService
    {
        [WebMethod]
        public List<Entity.QueryBuilder.FieldType> GetTypes()
        {
            try
            {
                var f = new FieldTypeLogic();
                return f.GetTypes();
            }
            catch(Exception exception)
            {
                ErrorLog.Log(exception);
                throw;
            }
        }
        [WebMethod(true)]
        public static void DeleteType(int id)
        {   try
            {
                var f = new FieldTypeLogic();
                f.DeleteType(new Entity.QueryBuilder.FieldType {Id = id});
            }
            catch(Exception exception)
            {
                ErrorLog.Log(exception);
                throw;
            }
        }
        [WebMethod(true)]
        public static void ActivateType(int id)
        {   try
            {
                var f = new FieldTypeLogic();
                f.UpdateType(new Entity.QueryBuilder.FieldType { Id = id });
            }
            catch(Exception exception)
            {
                ErrorLog.Log(exception);
                throw;
            }
        }
        [WebMethod(true)]
        public static void SaveType(int id, string name)
        {   try
            {
                var f = new FieldTypeLogic();
                if (id > 0)
                    f.UpdateType(new Entity.QueryBuilder.FieldType { Id = id, Name = name });
                else
                    f.NewType(new Entity.QueryBuilder.FieldType { Id = id, Name = name });
            }
            catch(Exception exception)
            {
                ErrorLog.Log(exception);
                throw;
            }
        }
        [WebMethod(true)]
        public static void DeleteSubType(int id)
        {   try
            {
                var f = new FieldTypeLogic();
                f.DeleteSubType(new Entity.QueryBuilder.FieldType { Id = id });
            }
            catch(Exception exception)
            {
                ErrorLog.Log(exception);
                throw;
            }
        }
        [WebMethod(true)]
        public static void ActivateSubType(int id)
        {   try
            {
                var f = new FieldTypeLogic();
                f.UpdateSubType(new Entity.QueryBuilder.FieldType { Id = id });
            }
            catch(Exception exception)
            {
                ErrorLog.Log(exception);
                throw;
            }
        }
        [WebMethod(true)]
        public static void SaveSubType(int id, int typeId, string name)
        {   try
            {
                var f = new FieldTypeLogic();
                if (id > 0)
                    f.UpdateSubType(new Entity.QueryBuilder.FieldType { Id = id, Name = name });
                else
                    f.NewSubType(typeId, new Entity.QueryBuilder.FieldType { Name = name });
            }
            catch (Exception exception)
            {
                ErrorLog.Log(exception);
                throw;
            }
        }

    }
}
