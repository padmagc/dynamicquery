﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using DynamicQuery.Logic;

namespace DynamicQuery.Web.Services
{
    /// <summary>
    /// Summary description for Field
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class Field : System.Web.Services.WebService
    {
        [WebMethod]
        public void InactivateField(int fieldId)
        {
            try
            {
                var f = new FieldLogic();
                f.DeleteField(fieldId);
            }
            catch (Exception exception)
            {
                ErrorLog.Log(exception);
                throw;
            }
        }
        [WebMethod]
        public void UpdateField(Entity.Documentation.DynamicQueryTableColumn column)
        {
            try
            {
                var f = new FieldLogic();
                f.UpdateField(column);
            }
            catch (Exception exception)
            {
                ErrorLog.Log(exception);
                throw;
            }
        }

    }
}
