﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Services;
using DynamicQuery.Entity.Documentation;
using DynamicQuery.Logic;

namespace DynamicQuery.Web
{
    public partial class Documentation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        [WebMethod(true)]
        public static List<string> GetTables()
        {
            var db = new Database();
            return db.Tables.Select(table => table.Name).ToList();
        }
        [WebMethod(true)]
        public static string GenerateDocumentation(string tableName)
        {
            try
            {
                var db = new Database();
                var table = db.Tables.SingleOrDefault(w => w.Name == tableName);
                if(table == null) throw new Exception("Ismeretlen tábla név : " + tableName);
                var generator = new DocumentationGenerator();
                generator.SaveDocumentation(table);

            }
            catch (Exception ex)
            {
                return String.Format("Error {0} : {1}", tableName, ex.Message);
            }
            return String.Format("{0} : OK", tableName);
        }
    }
}