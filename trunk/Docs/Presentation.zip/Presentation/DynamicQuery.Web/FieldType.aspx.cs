﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using DynamicQuery.Logic;

namespace DynamicQuery.Web
{
    public partial class FieldType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod(true)]
        public static List<Entity.QueryBuilder.FieldType> GetTypes()
        {
            var f = new FieldTypeLogic();
            return f.GetTypes();
        }
        [WebMethod(true)]
        public static void DeleteType(int id)
        {
            var f = new FieldTypeLogic();
            f.DeleteType(new Entity.QueryBuilder.FieldType{ Id = id});
        }
        [WebMethod(true)]
        public static void ActivateType(int id)
        {
            var f = new FieldTypeLogic();
            f.UpdateType(new Entity.QueryBuilder.FieldType { Id = id });
        }
        [WebMethod(true)]
        public static void SaveType(int id, string name)
        {
            var f = new FieldTypeLogic();
            if(id > 0)
                f.UpdateType(new Entity.QueryBuilder.FieldType { Id = id, Name = name});
            else
                f.NewType(new Entity.QueryBuilder.FieldType { Id = id, Name = name });
        }
        [WebMethod(true)]
        public static void DeleteSubType(int id)
        {
            var f = new FieldTypeLogic();
            f.DeleteSubType(new Entity.QueryBuilder.FieldType { Id = id });
        }
        [WebMethod(true)]
        public static void ActivateSubType(int id)
        {
            var f = new FieldTypeLogic();
            f.UpdateSubType(new Entity.QueryBuilder.FieldType { Id = id });
        }
        [WebMethod(true)]
        public static void SaveSubType(int id, int typeId, string name)
        {
            var f = new FieldTypeLogic();
            if (id > 0)
                f.UpdateSubType(new Entity.QueryBuilder.FieldType { Id = id, Name = name });
            else
                f.NewSubType(typeId, new Entity.QueryBuilder.FieldType { Name = name });
        }
    }
}